// Put your Supabase project values here.
// Supabase dashboard → Project Settings → API
window.SUPABASE_URL = "YOUR_SUPABASE_URL";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";